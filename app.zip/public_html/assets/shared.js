/**
 * shared.js — Couche données partagée entre index.html (ERP) et boutique.html
 * localStorage keys identiques → synchronisation automatique entre les deux pages
 * Version 1.0
 */

// ═══════════════════════════════════════════════════════════
//  CLÉS localStorage (partagées index.html ↔ boutique.html)
// ═══════════════════════════════════════════════════════════
var WWE_KEYS = {
  // Core ERP
  users:       'wwe_u5',
  session:     'wwe_s5',
  clients:     'wwe_c5',
  suppliers:   'wwe_sup5',
  products:    'wwe_p5',
  stockMov:    'wwe_sm5',
  documents:   'wwe_d5',
  purchaseInv: 'wwe_pi5',
  categories:  'wwe_cat5',
  cat_tree:    'wwe_cattree1',
  company:     'wwe_co5',
  notifications:'wwe_n5',
  reglements:  'wwe_r5',
  vehicles:    'wwe_veh1',
  returns:     'wwe_ret1',
  caisse:      'wwe_cai1',
  propdevis:   'wwe_prop1',
  retours_vente:'wwe_rv1',
  enc_vendeur: 'wwe_env1',
  promotions:  'wwe_promo1',
  // Multi-dépôts
  entrepots:   'wwe_ent1',
  transferts:  'wwe_tr1',
  ventes_vendeur:'wwe_vv1',
  // POS
  stores:      'wwe_stores1',
  pos_sales:   'wwe_pos1',
  pos_retours: 'wwe_posret1',
  pos_commandes:'wwe_poscmd1',
  pos_defectueux:'wwe_posdef1',
  // E-Commerce Boutique
  online_orders:'wwe_orders1',
  buyers:      'wwe_buyers1'
};

// ═══════════════════════════════════════════════════════════
//  FONCTIONS UTILITAIRES DE BASE
// ═══════════════════════════════════════════════════════════

/** Lire un tableau depuis localStorage */
function wweGet(key) {
  try { return JSON.parse(localStorage.getItem(key)) || []; }
  catch(e) { return []; }
}

/** Lire un objet depuis localStorage */
function wweGetObj(key) {
  try { return JSON.parse(localStorage.getItem(key)) || {}; }
  catch(e) { return {}; }
}

/** Écrire dans localStorage */
function wweSave(key, data) {
  try { localStorage.setItem(key, JSON.stringify(data)); return true; }
  catch(e) { console.warn('[WWE] Storage error:', e); return false; }
}

/** Formater un nombre en 2 décimales */
function wweFmt2(n) {
  return Number(n || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/** Formater une valeur courte (K, M) */
function wweFmtVal(n) {
  n = Number(n || 0);
  if (n >= 1000000) return (n/1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n/1000).toFixed(0) + 'K';
  return wweFmt2(n);
}

/** Formater une date */
function wweFmtDate(d) {
  if (!d) return '—';
  try { return new Date(d).toLocaleDateString('fr-FR', {day:'2-digit',month:'2-digit',year:'numeric'}); }
  catch(e) { return d; }
}

/** Obtenir les infos société */
function wweGetCompany() {
  return wweGetObj(WWE_KEYS.company);
}

/** Obtenir la devise */
function wweGetCurrency() {
  return wweGetCompany().currency || 'DH';
}

// ═══════════════════════════════════════════════════════════
//  NOTIFICATIONS (cross-page)
// ═══════════════════════════════════════════════════════════

/**
 * Ajouter une notification visible dans index.html
 * Appelable depuis boutique.html → visible dans l'ERP
 */
function wweAddNotif(msg, docId, type) {
  type = type || 'info';
  var notifs = wweGet(WWE_KEYS.notifications);
  notifs.unshift({
    id: Date.now(),
    msg: msg,
    docId: docId || null,
    type: type,
    date: new Date().toISOString(),
    read: false
  });
  wweSave(WWE_KEYS.notifications, notifs.slice(0, 80));
}

// ═══════════════════════════════════════════════════════════
//  STOCK — Gestion synchronisée
// ═══════════════════════════════════════════════════════════

/**
 * Calculer le stock disponible dans un entrepôt spécifique
 * Utilisé par ERP ET boutique pour afficher le bon stock
 */
function wweGetEntrepotStock(entId) {
  var stockMap = {};
  var entIdStr = String(entId);

  // + Transferts entrants validés
  wweGet(WWE_KEYS.transferts)
    .filter(function(t){ return String(t.entrepot_id) === entIdStr && t.status === 'valide'; })
    .forEach(function(t){
      (t.lines || []).forEach(function(l){
        var pid = String(l.product_id);
        stockMap[pid] = (stockMap[pid] || 0) + (parseInt(l.qty) || 0);
      });
    });

  // - Ventes terrain
  wweGet(WWE_KEYS.ventes_vendeur)
    .filter(function(v){ return String(v.entrepot_id) === entIdStr && v.status !== 'annule'; })
    .forEach(function(v){
      (v.lines || []).forEach(function(l){
        var pid = String(l.product_id);
        stockMap[pid] = (stockMap[pid] || 0) - (parseInt(l.qty) || 0);
      });
    });

  // - Ventes POS liées à cet entrepôt
  var storeIds = wweGet(WWE_KEYS.stores)
    .filter(function(s){ return String(s.entrepot_id) === entIdStr; })
    .map(function(s){ return s.id; });

  wweGet(WWE_KEYS.pos_sales)
    .filter(function(s){ return storeIds.includes(s.store_id) && s.status !== 'annule'; })
    .forEach(function(s){
      (s.lines || []).forEach(function(l){
        var pid = String(l.product_id);
        stockMap[pid] = (stockMap[pid] || 0) - (parseInt(l.qty) || 0);
      });
    });

  return stockMap;
}

/**
 * Déduire le stock lors de la validation d'une commande boutique
 * Appelé depuis index.html quand le magasinier valide une commande
 */
function wweDeductStockForOrder(order) {
  if (!order || !order.lines || !order.lines.length) return false;

  // Trouver l'entrepôt lié au magasin assigné
  var entrepotId = order.assigned_entrepot_id;
  if (!entrepotId) {
    var store = wweGet(WWE_KEYS.stores).find(function(s){ return s.id === order.assigned_store_id; });
    if (store) entrepotId = store.entrepot_id;
  }

  // Enregistrer les mouvements de stock
  var moves = wweGet(WWE_KEYS.stockMov);
  order.lines.forEach(function(l) {
    moves.push({
      id: 'ORDER-' + Date.now() + '-' + l.product_id,
      type: 'sortie',
      product_id: l.product_id,
      product_name: l.name,
      qty: l.qty,
      reason: 'Vente boutique — ' + order.id + ' — ' + (order.buyer_name || 'Client'),
      entrepot_id: entrepotId,
      store_id: order.assigned_store_id,
      date: new Date().toISOString(),
      by: 'Boutique en ligne',
      order_id: order.id
    });
  });
  wweSave(WWE_KEYS.stockMov, moves);

  // Mettre à jour le stock global produit
  var products = wweGet(WWE_KEYS.products);
  order.lines.forEach(function(l) {
    var idx = products.findIndex(function(p){ return p.id === l.product_id; });
    if (idx >= 0) {
      products[idx].stock = Math.max(0, (products[idx].stock || 0) - l.qty);
    }
  });
  wweSave(WWE_KEYS.products, products);

  return true;
}

// ═══════════════════════════════════════════════════════════
//  PRODUITS — Boutique en ligne
// ═══════════════════════════════════════════════════════════

/** Obtenir les produits visibles en boutique */
function wweGetOnlineProducts() {
  return wweGet(WWE_KEYS.products)
    .filter(function(p){ return p.active !== false && p.online && (p.stock || 0) > 0; });
}

/** Activer/désactiver un produit en boutique */
function wweToggleProductOnline(productId, online) {
  var products = wweGet(WWE_KEYS.products);
  var idx = products.findIndex(function(p){ return p.id === productId; });
  if (idx >= 0) {
    products[idx].online = online;
    wweSave(WWE_KEYS.products, products);
    return true;
  }
  return false;
}

// ═══════════════════════════════════════════════════════════
//  COMMANDES BOUTIQUE — Gestion
// ═══════════════════════════════════════════════════════════

/** Créer une nouvelle commande boutique */
function wweCreateOrder(orderData) {
  var orders = wweGet(WWE_KEYS.online_orders);
  var order = Object.assign({
    id: 'CMD-WEB-' + Date.now(),
    date: new Date().toISOString(),
    status: 'nouvelle'
  }, orderData);
  orders.push(order);
  wweSave(WWE_KEYS.online_orders, orders);

  // Notifier l'ERP
  wweAddNotif(
    '🛒 Nouvelle commande boutique — ' + (order.buyer_name || 'Client') +
    ' — ' + (order.assigned_store_name || 'Dépôt principal') +
    ' — ' + wweFmt2(order.total) + ' ' + wweGetCurrency(),
    order.id,
    'online_order'
  );

  return order;
}

/** Mettre à jour le statut d'une commande */
function wweUpdateOrderStatus(orderId, status, updatedBy) {
  var orders = wweGet(WWE_KEYS.online_orders);
  var idx = orders.findIndex(function(o){ return o.id === orderId; });
  if (idx < 0) return null;

  orders[idx].status = status;
  orders[idx].updated_by = updatedBy || 'ERP';
  orders[idx].updated_at = new Date().toISOString();

  // Si livraison confirmée → déduire le stock
  if (status === 'livree') {
    wweDeductStockForOrder(orders[idx]);
    wweAddNotif(
      '✅ Commande livrée — ' + orderId + ' — Stock mis à jour',
      orderId, 'order_delivered'
    );
  }

  wweSave(WWE_KEYS.online_orders, orders);
  return orders[idx];
}

/** Trouver le magasin le plus proche d'une ville */
function wweFindNearestStore(city) {
  var stores = wweGet(WWE_KEYS.stores).filter(function(s){ return s.active !== false; });
  if (!city || !stores.length) return stores[0] || null;

  var cityLow = city.toLowerCase();

  // Match direct par ville
  var match = stores.find(function(s){
    return (s.city && s.city.toLowerCase().includes(cityLow)) ||
           (s.address && s.address.toLowerCase().includes(cityLow));
  });
  if (match) return match;

  // Match par zone géo de l'entrepôt
  var entrepots = wweGet(WWE_KEYS.entrepots);
  var ent = entrepots.find(function(e){
    return e.zone_geo && e.zone_geo.toLowerCase().includes(cityLow);
  });
  if (ent) {
    var storeForEnt = stores.find(function(s){ return String(s.entrepot_id) === String(ent.id); });
    if (storeForEnt) return storeForEnt;
  }

  return stores[0] || null;
}

// ═══════════════════════════════════════════════════════════
//  ACHETEURS (Boutique)
// ═══════════════════════════════════════════════════════════

/** Créer un compte acheteur */
function wweRegisterBuyer(data) {
  var buyers = wweGet(WWE_KEYS.buyers);
  if (buyers.find(function(b){ return b.email === data.email; })) {
    return { error: 'Email déjà utilisé' };
  }
  var buyer = Object.assign({ id: 'BUY-' + Date.now(), createdAt: new Date().toISOString() }, data);
  buyers.push(buyer);
  wweSave(WWE_KEYS.buyers, buyers);
  return { buyer: buyer };
}

/** Connecter un acheteur */
function wweLoginBuyer(email, password) {
  var buyers = wweGet(WWE_KEYS.buyers);
  var found = buyers.find(function(b){ return b.email === email && b.password === password; });
  return found || null;
}

/** Obtenir les commandes d'un acheteur */
function wweGetBuyerOrders(buyerId) {
  return wweGet(WWE_KEYS.online_orders)
    .filter(function(o){ return o.buyer_id === buyerId; })
    .sort(function(a,b){ return a.date < b.date ? 1 : -1; });
}

// ═══════════════════════════════════════════════════════════
//  NAVIGATION (liens entre les deux fichiers)
// ═══════════════════════════════════════════════════════════

/** Détecter si on est dans l'ERP ou la boutique */
var WWE_IS_ERP = (window.location.pathname.includes('index.html') ||
                  window.location.pathname === '/' ||
                  window.location.pathname.endsWith('/'));
var WWE_IS_SHOP = window.location.pathname.includes('boutique.html');

/** Obtenir l'URL relative de la boutique */
function wweGetShopUrl() {
  return 'boutique.html';
}

/** Obtenir l'URL relative de l'ERP */
function wweGetErpUrl() {
  return 'index.html';
}

/** Ouvrir la boutique dans un nouvel onglet */
function wweOpenShop() {
  window.open(wweGetShopUrl(), '_blank');
}

/** Ouvrir l'ERP dans un nouvel onglet */
function wweOpenErp() {
  window.open(wweGetErpUrl(), '_blank');
}

// ═══════════════════════════════════════════════════════════
//  SYNCHRO EN TEMPS RÉEL (StorageEvent)
// ═══════════════════════════════════════════════════════════

/**
 * Écouter les changements localStorage depuis l'autre page
 * Utile pour actualiser la boutique quand l'ERP modifie un produit
 * ou pour actualiser l'ERP quand la boutique passe une commande
 */
function wweListenSync(callback) {
  window.addEventListener('storage', function(e) {
    if (!e.key) return;
    // Vérifier si la clé modifiée est une clé WWE
    var isWweKey = Object.values(WWE_KEYS).some(function(v){ return v === e.key; });
    if (isWweKey && typeof callback === 'function') {
      callback(e.key, e.newValue, e.oldValue);
    }
  });
}

// ═══════════════════════════════════════════════════════════
//  INIT — Vérification / Initialisation des clés
// ═══════════════════════════════════════════════════════════

function wweInitStorage() {
  var defaults = [
    { key: WWE_KEYS.products,       val: [] },
    { key: WWE_KEYS.categories,     val: ['Solaire','Onduleur','Batterie','Accessoire','Cablage','Structure','Monitoring','Protection','Eclairage LED','Pompage Solaire'] },
    { key: WWE_KEYS.stores,         val: [] },
    { key: WWE_KEYS.entrepots,      val: [] },
    { key: WWE_KEYS.online_orders,  val: [] },
    { key: WWE_KEYS.buyers,         val: [] },
    { key: WWE_KEYS.notifications,  val: [] },
    { key: WWE_KEYS.stockMov,       val: [] },
    { key: WWE_KEYS.pos_retours,    val: [] },
    { key: WWE_KEYS.pos_commandes,  val: [] },
    { key: WWE_KEYS.pos_defectueux, val: [] },
    { key: WWE_KEYS.transferts,     val: [] },
    { key: WWE_KEYS.ventes_vendeur, val: [] }
  ];
  defaults.forEach(function(d){
    if (!localStorage.getItem(d.key)) wweSave(d.key, d.val);
  });
}

// Auto-init
wweInitStorage();

// ═══════════════════════════════════════════════════════════
//  EXPORT (compatibilité ERP React + boutique vanilla JS)
// ═══════════════════════════════════════════════════════════
if (typeof window !== 'undefined') {
  window.WWE = {
    keys:            WWE_KEYS,
    get:             wweGet,
    getObj:          wweGetObj,
    save:            wweSave,
    fmt2:            wweFmt2,
    fmtVal:          wweFmtVal,
    fmtDate:         wweFmtDate,
    getCompany:      wweGetCompany,
    getCurrency:     wweGetCurrency,
    addNotif:        wweAddNotif,
    getEntrepotStock:wweGetEntrepotStock,
    deductStock:     wweDeductStockForOrder,
    getOnlineProds:  wweGetOnlineProducts,
    toggleOnline:    wweToggleProductOnline,
    createOrder:     wweCreateOrder,
    updateOrder:     wweUpdateOrderStatus,
    findNearestStore:wweFindNearestStore,
    registerBuyer:   wweRegisterBuyer,
    loginBuyer:      wweLoginBuyer,
    getBuyerOrders:  wweGetBuyerOrders,
    openShop:        wweOpenShop,
    openErp:         wweOpenErp,
    listenSync:      wweListenSync,
    isErp:           WWE_IS_ERP,
    isShop:          WWE_IS_SHOP
  };
}

console.log('[WWE Shared.js v1.0] Loaded —', WWE_IS_ERP ? 'ERP Mode' : 'Shop Mode');
