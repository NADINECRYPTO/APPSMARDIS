/**
 * smardis-api.js v6.1 — SECURITE COMPLETE
 *
 * PROBLEME RESOLU:
 * wwe_s5 (session) était dans MySQL → partagé entre tous les navigateurs
 *
 * SOLUTION:
 * 1. wwe_s5 JAMAIS envoyé/reçu de MySQL
 * 2. Token serveur unique par navigateur
 * 3. Auto-logout après 10 min d'inactivité
 * 4. Nettoyage de wwe_s5 dans MySQL au démarrage
 */
(function(){
'use strict';

var API_URL='/api/smardis';

// ══ CLÉ JAMAIS SYNCHRONISÉE (session = locale uniquement) ══
var NO_SYNC = {'wwe_s5':1};

var TOKEN_KEY     = 'smardis_srv_token';
var SESSION_KEY   = 'wwe_s5';
var TIMEOUT_MS    = 10 * 60 * 1000;  // 10 minutes
var WARNING_MS    = TIMEOUT_MS - 30 * 1000; // Avertissement 30 sec avant déconnexion

window.SMARDIS_DB = window.SMARDIS_DB||{};
var DB = window.SMARDIS_DB;

var PULLING = false;
var TIMERS  = {};
var _tTimeout=null, _tWarning=null, _actBound=false;

var SYNC_KEYS=['wwe_u5','wwe_c5','wwe_sup5','wwe_p5','wwe_sm5','wwe_d5',
               'wwe_pi5','wwe_cat5','wwe_cattree1','wwe_co5','wwe_n5','wwe_r5',
               'wwe_veh1','wwe_ret1','wwe_cai1','wwe_prop1','wwe_rv1','wwe_env1',
               'wwe_promo1','wwe_ent1','wwe_tr1','wwe_vv1','wwe_stores1','wwe_pos1',
               'wwe_posret1','wwe_poscmd1','wwe_posdef1','wwe_orders1','wwe_buyers1'];

function jp(v,fb){try{return JSON.parse(v);}catch(e){return fb;}}
function lsW(k,v){try{(window.__origLS||Storage.prototype.setItem).call(localStorage,k,JSON.stringify(v));}catch(e){}}
function lsR(k,fb){try{var v=localStorage.getItem(k);return v?JSON.parse(v):fb;}catch(e){return fb;}}

// ── Appel API synchrone (bloquant) ───────────────────
function apiS(data){
  try{
    var tok=localStorage.getItem(TOKEN_KEY)||'';
    var x=new XMLHttpRequest();
    x.open('POST',API_URL,false);
    x.setRequestHeader('Content-Type','application/json');
    if(tok)x.setRequestHeader('X-Token',tok);
    x.send(JSON.stringify(data));
    if(x.status>=200&&x.status<300)return jp(x.responseText,{success:false});
    return {success:false,error:'HTTP '+x.status};
  }catch(e){return{success:false,error:e.message};}
}

// ── Appel API asynchrone ──────────────────────────────
function apiA(data,ms){
  ms=ms||10000;
  var tok=localStorage.getItem(TOKEN_KEY)||'';
  var ctrl=window.AbortController?new AbortController():null;
  var t=ctrl?setTimeout(function(){ctrl.abort();},ms):null;
  return fetch(API_URL,{
    method:'POST',
    headers:{'Content-Type':'application/json','X-Token':tok},
    body:JSON.stringify(data),
    signal:ctrl?ctrl.signal:undefined
  }).then(function(r){if(t)clearTimeout(t);return r.text().then(function(tx){return jp(tx,{success:false});});})
    .catch(function(e){if(t)clearTimeout(t);return{success:false,error:e.message};});
}

// ══════════════════════════════════════════════════════
//  LOADER
// ══════════════════════════════════════════════════════
function showL(msg,pct){
  var el=document.getElementById('smardis-loader');
  if(!el){
    el=document.createElement('div');el.id='smardis-loader';
    el.style.cssText='position:fixed;inset:0;z-index:99999;background:linear-gradient(135deg,#0F1A45,#1B2A6B);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:20px;font-family:sans-serif';
    el.innerHTML=
      '<div style="width:68px;height:68px;border-radius:20px;background:linear-gradient(135deg,#C9A84C,#A8893A);display:flex;align-items:center;justify-content:center;box-shadow:0 6px 24px rgba(201,168,76,.4);animation:_ld_p 1.5s ease infinite">'
        +'<svg width="30" height="30" viewBox="0 0 24 24" fill="white"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>'
      +'</div>'
      +'<div style="color:#C9A84C;font-size:20px;font-weight:900;letter-spacing:2px">SMARDIS</div>'
      +'<div style="color:rgba(255,255,255,.75);font-size:13px;text-align:center;padding:0 30px;max-width:320px" id="sld-msg">Sécurisation...</div>'
      +'<div style="width:240px;height:5px;background:rgba(255,255,255,.1);border-radius:99px;overflow:hidden">'
        +'<div id="sld-bar" style="height:100%;background:linear-gradient(90deg,#C9A84C,#FBD87F);border-radius:99px;width:5%;transition:width .5s ease"></div>'
      +'</div>'
      +'<style>@keyframes _ld_p{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.08);opacity:.85}}</style>';
    document.body.appendChild(el);
  }
  var s=document.getElementById('sld-msg');if(s)s.textContent=msg||'';
  var b=document.getElementById('sld-bar');if(b)b.style.width=(pct||5)+'%';
}

function smardisFatalDB(title, detail){
  try{
    var msg = title || 'MySQL obligatoire';
    var det = detail || '';
    ['smardis-loader','smardis-db-loader'].forEach(function(id){
      var el=document.getElementById(id);
      if(!el) return;
      el.style.display='flex'; el.style.visibility='visible'; el.style.opacity='1'; el.style.pointerEvents='auto';
      el.innerHTML='<div style="max-width:520px;text-align:center;color:#fff;font-family:Arial,sans-serif;padding:25px">'
        +'<div style="width:86px;height:86px;margin:0 auto 18px;border-radius:24px;background:#C9A84C;display:flex;align-items:center;justify-content:center;font-size:34px">🔒</div>'
        +'<h1 style="color:#C9A84C;letter-spacing:3px;margin:0 0 16px">SMARDIS</h1>'
        +'<h2 style="margin:0 0 12px;font-size:20px">⚠ '+msg+'</h2>'
        +(det?'<pre style="white-space:pre-wrap;text-align:left;background:rgba(0,0,0,.28);padding:12px;border-radius:12px;max-height:180px;overflow:auto">'+String(det).replace(/[<>&]/g,function(c){return {"<":"&lt;",">":"&gt;","&":"&amp;"}[c]})+'</pre>':'')
        +'<p style="line-height:1.5">Ouvrez <b>diagnostic.php</b>. Si tout est OK, videz le cache avec <b>Ctrl+F5</b>.</p>'
        +'<p><a href="diagnostic.php" style="display:inline-block;background:#C9A84C;color:#0F1A45;font-weight:900;padding:11px 18px;border-radius:10px;text-decoration:none">Ouvrir diagnostic</a> '
        +'<a href="api.php?action=ping" style="display:inline-block;background:#fff;color:#0F1A45;font-weight:900;padding:11px 18px;border-radius:10px;text-decoration:none;margin-left:8px">Tester API</a></p>'
        +'</div>';
    });
  }catch(e){}
}

function hideL(){
  // Corrige le blocage sur "Chargement du système..." :
  // il existe 2 loaders dans index.html. On doit fermer les deux.
  ['smardis-loader','smardis-db-loader'].forEach(function(id){
    var el=document.getElementById(id);
    if(!el)return;
    try{el.classList.add('smardis-hide');}catch(e){}
    el.style.transition='opacity .4s, visibility .4s';
    el.style.opacity='0';
    el.style.visibility='hidden';
    el.style.pointerEvents='none';
    setTimeout(function(){if(el&&el.parentNode)el.parentNode.removeChild(el);},520);
  });
}
window.smardisSetLoader=showL;
window.smardisHideLoader=hideL;

// ══════════════════════════════════════════════════════
//  TIMER INACTIVITÉ — 10 MINUTES
// ══════════════════════════════════════════════════════
function startInactivityTimer(){
  clearTimeout(_tTimeout);
  clearTimeout(_tWarning);

  // Avertissement à 9 min
  _tWarning=setTimeout(function(){showWarning();},WARNING_MS);

  // Logout à 10 min
  _tTimeout=setTimeout(function(){
    hideWarning();
    doAutoLogout();
  },TIMEOUT_MS);
}
window.smardisStartInactivityTimer=startInactivityTimer;

function resetTimer(){
  hideWarning();
  startInactivityTimer();
}

function stopTimer(){
  clearTimeout(_tTimeout);
  clearTimeout(_tWarning);
  hideWarning();
}

function showWarning(){
  if(document.getElementById('sld-warn'))return;
  var d=document.createElement('div');d.id='sld-warn';
  d.style.cssText='position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:99998;background:#1B2A6B;color:#fff;padding:14px 20px;border-radius:14px;border:2px solid #C9A84C;font-family:sans-serif;font-size:13px;font-weight:700;display:flex;align-items:center;gap:12px;box-shadow:0 8px 32px rgba(0,0,0,.4);max-width:min(420px,94vw);animation:_ld_p .4s ease';
  d.innerHTML=
    '<svg width="22" height="22" viewBox="0 0 24 24" fill="#C9A84C" style="flex-shrink:0"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>'
    +'<div style="flex:1"><div>Session expire dans <strong style="color:#C9A84C" id="sld-cdown">30</strong> secondes</div><div style="font-size:11px;opacity:.6;margin-top:2px">Cliquez pour rester connecté</div></div>'
    +'<button onclick="window.smardisStayActive&&window.smardisStayActive()" style="background:#C9A84C;color:#fff;border:none;border-radius:9px;padding:9px 16px;font-weight:900;cursor:pointer;font-family:inherit;font-size:12px;white-space:nowrap">Rester connecté</button>';
  document.body.appendChild(d);
  // Compte à rebours
  var n=30;var iv=setInterval(function(){n--;var el=document.getElementById('sld-cdown');if(el)el.textContent=n;if(n<=0)clearInterval(iv);},1000);
  d._iv=iv;
}

function hideWarning(){
  var d=document.getElementById('sld-warn');
  if(d){clearInterval(d._iv);d.parentNode&&d.parentNode.removeChild(d);}
}

function doAutoLogout(){
  stopTimer();
  clearLocalSession();
  if(typeof window.smardisOnAutoLogout==='function'){
    window.smardisOnAutoLogout('Session expirée après 10 minutes d\'inactivité');
  } else {
    window.location.reload();
  }
}

window.smardisStayActive=function(){resetTimer();apiA({action:'verify_token'},5000);};

function bindActivity(){
  if(_actBound)return;_actBound=true;
  ['mousedown','keydown','scroll','touchstart','click'].forEach(function(ev){
    document.addEventListener(ev,resetTimer,{passive:true});
  });
}

// ══════════════════════════════════════════════════════
//  SÉCURITÉ SESSION — Token par navigateur
// ══════════════════════════════════════════════════════
function clearLocalSession(){
  try{localStorage.removeItem(SESSION_KEY);}catch(e){}
  try{localStorage.removeItem(TOKEN_KEY);}catch(e){}
  if(DB[SESSION_KEY])delete DB[SESSION_KEY];
}

function verifySess(){
  var tok=localStorage.getItem(TOKEN_KEY);
  if(!tok){
    clearLocalSession();
    return false;
  }
  var res=apiS({action:'verify_token',token:tok});
  if(res&&res.success)return true;
  // MySQL obligatoire: si l'API/MySQL ne répond pas, la session n'est pas valide.
  if(!res || !res.success){
    clearLocalSession();
    return false;
  }
  clearLocalSession();
  return false;
}

// ── Login ────────────────────────────────────────────
window.smardisServerLogin=function(email,pwd){
  return apiA({action:'login',email:email,password:pwd},15000)
    .then(function(r){
      if(r&&r.success&&r.data&&r.data.token){
        localStorage.setItem(TOKEN_KEY,r.data.token);
        startInactivityTimer();
        bindActivity();
      }
      return r;
    });
};

// ── Logout ────────────────────────────────────────────
window.smardisServerLogout=function(){
  stopTimer();
  var tok=localStorage.getItem(TOKEN_KEY)||'';
  clearLocalSession();
  return apiA({action:'logout',token:tok},6000);
};

// ══════════════════════════════════════════════════════
//  PATCH localStorage → Auto-save MySQL
//  wwe_s5 JAMAIS envoyé à MySQL
// ══════════════════════════════════════════════════════
(function patchLS(){
  if(Storage.prototype.__sp)return;
  Storage.prototype.__sp=true;
  window.__origLS=Storage.prototype.setItem;
  Storage.prototype.setItem=function(k,v){
    window.__origLS.call(this,k,v);
    if(PULLING)return;
    if(String(k).indexOf('wwe_')!==0)return;
    var d=jp(v,null);if(d===null)return;
    DB[k]=d;
    // ⛔ Session → jamais en MySQL
    if(NO_SYNC[k])return;
    // ✅ Données métier → MySQL
    clearTimeout(TIMERS[k]);
    TIMERS[k]=setTimeout(function(){
      apiA({action:'sync_push',key:k,data:d},12000);
    },400);
  };
})();

window.g  =function(k){return DB[k]!==undefined?DB[k]:lsR(k,[]);};
window.gs =function(k){return DB[k]!==undefined?DB[k]:lsR(k,{});};
window.sv =function(k,d){DB[k]=d;localStorage.setItem(k,JSON.stringify(d));};

// ── Appliquer données MySQL au navigateur ─────────────
function notifyRefresh(reason){
  try{document.dispatchEvent(new CustomEvent('wwe_stock_update',{detail:{key:reason||'sync'}}));}catch(e){}
  try{window.dispatchEvent(new CustomEvent('wwe_stock_update',{detail:{key:reason||'sync'}}));}catch(e){}
  if(typeof window.triggerAppRefresh==='function'){
    try{window.triggerAppRefresh(reason||'sync');}catch(e){}
  }
}

function applyData(data){
  if(!data)return false;
  var changed=false;PULLING=true;
  Object.keys(data).forEach(function(k){
    if(NO_SYNC[k])return;       // ⛔ Jamais appliquer session MySQL
    if(k.indexOf('__')===0)return;
    var val=data[k];if(val===undefined||val===null)return;

    // Protection: ne pas écraser les données locales par un tableau/objet vide venant de MySQL
    var localRaw=localStorage.getItem(k);
    var localVal=jp(localRaw,null);
    var remoteEmpty=(Array.isArray(val)&&val.length===0)||(typeof val==='object'&&!Array.isArray(val)&&Object.keys(val).length===0);
    var localHasData=(Array.isArray(localVal)&&localVal.length>0)||(localVal&&typeof localVal==='object'&&!Array.isArray(localVal)&&Object.keys(localVal).length>0);
    if(remoteEmpty&&localHasData){ DB[k]=localVal; return; }

    var prev=localStorage.getItem(k);
    var nw=JSON.stringify(val);
    if(prev!==nw)changed=true;
    DB[k]=val;lsW(k,val);
  });
  PULLING=false;return changed;
}

function pushAll(){
  SYNC_KEYS.forEach(function(k){
    if(NO_SYNC[k])return;
    var v=localStorage.getItem(k);
    if(!v||v==='[]'||v==='{}'||v==='null')return;
    var d=jp(v,null);if(!d)return;
    apiS({action:'sync_push',key:k,data:d});DB[k]=d;
  });
}

// ══════════════════════════════════════════════════════
//  NETTOYAGE — Supprimer wwe_s5 de MySQL
// ══════════════════════════════════════════════════════
function cleanSessionFromMySQL(){
  // Supprimer wwe_s5 de sync_store si elle y est encore
  apiA({action:'delete_key',key:SESSION_KEY},5000).then(function(r){
    if(r&&r.success)console.log('[SMARDIS] wwe_s5 supprimé de MySQL ✅');
  }).catch(function(){});
}

// ══════════════════════════════════════════════════════
//  BOOT
// ══════════════════════════════════════════════════════
(function boot(){
  showL('Vérification de la sécurité...',10);

  // 1. Vérifier token serveur
  verifySess(); // si invalide → session effacée → React montrera login

  // 2. Connexion MySQL
  showL('Connexion à la base de données...',25);
  var ping=apiS({action:'ping'});
  window.SMARDIS_LAST_PING=ping;

  if(!ping||!ping.success){
    var msg=(ping&&ping.error)?ping.error:'Base de données inaccessible';
    showL('⚠ MySQL obligatoire: '+msg,100);
    window.SMARDIS_DB_REQUIRED_ERROR=ping;
    smardisFatalDB('MySQL/API inaccessible', msg + '\n\napi.php?action=ping doit retourner success:true');
    return;
  }

  // 3. Première installation → pousser données locales
  if(ping.data&&Number(ping.data.sync_store_keys||0)===0){
    var hasLocal=SYNC_KEYS.some(function(k){
      var v=localStorage.getItem(k);return v&&v!=='[]'&&v!=='{}'&&v!=='null';
    });
    if(hasLocal){showL('Initialisation...',40);pushAll();}
  }

  // 4. Charger données depuis MySQL (sans wwe_s5)
  showL('Chargement des données...',60);
  var res=apiS({action:'sync_pull'});
  window.SMARDIS_LAST_PULL=res;

  if(res&&res.success&&res.data){
    var _changedBoot=applyData(res.data); // ← exclut wwe_s5 automatiquement
    if(_changedBoot)notifyRefresh('boot');
    showL('✅ '+Object.keys(res.data).length+' tables chargées',90);
  } else {
    showL('⚠ Erreur chargement MySQL',90);
    window.SMARDIS_DB_REQUIRED_ERROR=res;
    smardisFatalDB('Erreur sync_pull', JSON.stringify(res||{}, null, 2));
    return;
  }

  // 5. Si session valide → démarrer timer
  if(localStorage.getItem(TOKEN_KEY)&&localStorage.getItem(SESSION_KEY)){
    startInactivityTimer();
    bindActivity();
  }

  // 6. Nettoyer wwe_s5 de MySQL (clé de session)
  cleanSessionFromMySQL();
})();

// ── Polling 5s ────────────────────────────────────────
function poll(){
  return apiA({action:'sync_pull'},12000).then(function(r){
    if(r&&r.success&&r.data){
      var ch=applyData(r.data);
      if(ch)notifyRefresh('sync');
    }
  });
}

function ready(){
  // MySQL obligatoire : cacher le loader seulement si ping + chargement OK.
  setTimeout(function(){
    if(window.SMARDIS_LAST_PING&&window.SMARDIS_LAST_PING.success&&window.SMARDIS_LAST_PULL&&window.SMARDIS_LAST_PULL.success){ hideL(); }
    else if(window.SMARDIS_DB_REQUIRED_ERROR){ smardisFatalDB('MySQL obligatoire', JSON.stringify(window.SMARDIS_DB_REQUIRED_ERROR,null,2)); }
  },800);
  setInterval(poll,5000);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);
else ready();
setTimeout(function(){
  if(window.SMARDIS_LAST_PING&&window.SMARDIS_LAST_PING.success&&window.SMARDIS_LAST_PULL&&window.SMARDIS_LAST_PULL.success) hideL();
},10000);

window.smardisForceSync=poll;
window.smardisPushAllToDB=function(){return new Promise(function(r){pushAll();r(true);});};
window.smardisDBTest=function(){return apiA({action:'ping'},8000);};

console.log('[SMARDIS v6.1] Sécurité: session locale, timeout 10min, wwe_s5 exclus de MySQL');
})();
