/*
SMARDIS API helper multi-utilisateur.
À utiliser si tu veux appeler l'API depuis erp.blade.php ou boutique.blade.php
*/

window.SMARDIS_API = {
  tokenKey: 'smardis_api_token',
  userKey: 'smardis_current_user',

  token(){
    return localStorage.getItem(this.tokenKey) || '';
  },

  user(){
    try { return JSON.parse(localStorage.getItem(this.userKey) || 'null'); }
    catch(e){ return null; }
  },

  async call(action, data = {}){
    const headers = {'Content-Type': 'application/json'};
    const token = this.token();
    if(token) headers['Authorization'] = 'Bearer ' + token;

    const r = await fetch('/api/smardis?action=' + encodeURIComponent(action), {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
      cache: 'no-store'
    });

    const txt = await r.text();
    let j;
    try { j = JSON.parse(txt); }
    catch(e){ throw new Error(txt.slice(0, 500)); }

    if(!j.success) throw new Error(j.error || 'Erreur API');
    return j;
  },

  async login(email, password){
    const j = await this.call('login', {email, password});
    localStorage.setItem(this.tokenKey, j.token);
    localStorage.setItem(this.userKey, JSON.stringify(j.user));
    return j;
  },

  async logout(){
    try { await this.call('logout', {}); } catch(e){}
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  },

  async syncPull(){
    return await this.call('sync_pull', {});
  },

  async syncPush(key, data){
    return await this.call('sync_push', {key, data});
  }
};
