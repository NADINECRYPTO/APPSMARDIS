<?php
opcache_reset();

@unlink('/home/smardy78/smardis_laravel/bootstrap/cache/config.php');
@unlink('/home/smardy78/smardis_laravel/bootstrap/cache/routes-v7.php');

echo "Cache Laravel vidé OK";