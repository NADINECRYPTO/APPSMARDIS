<?php

return array(
    'paths' => array(
        '/home/smardy78/smardis_laravel/resources/views',
    ),

    'compiled' => '/home/smardy78/smardis_laravel/storage/framework/views',
);