<?php

use Illuminate\Support\ServiceProvider;

return [
    'name' => env('APP_NAME', 'SMARDIS'),
    'env' => env('APP_ENV', 'production'),
    'debug' => (bool) env('APP_DEBUG', false),
    'url' => env('APP_URL', 'http://localhost'),
    'asset_url' => env('ASSET_URL'),
    'timezone' => 'Africa/Casablanca',
    'locale' => 'fr',
    'fallback_locale' => 'fr',
    'faker_locale' => 'fr_FR',
    'key' => env('APP_KEY'),
    'cipher' => 'AES-256-CBC',
    'maintenance' => ['driver' => 'file'],
    'providers' => ServiceProvider::defaultProviders()->merge([
        
        App\Providers\RouteServiceProvider::class,
        App\Providers\AppServiceProvider::class,
    ])->toArray(),
    'aliases' => [],
];
