<?php

return array(
    'defaults' => array(
        'guard' => 'web',
        'passwords' => 'users',
    ),

    'guards' => array(
        'web' => array(
            'driver' => 'session',
            'provider' => 'users',
        ),

        'api' => array(
            'driver' => 'session',
            'provider' => 'users',
        ),
    ),

    'providers' => array(
        'users' => array(
            'driver' => 'database',
            'table' => 'users',
        ),
    ),

    'passwords' => array(
        'users' => array(
            'provider' => 'users',
            'table' => 'password_reset_tokens',
            'expire' => 60,
            'throttle' => 60,
        ),
    ),

    'password_timeout' => 10800,
);