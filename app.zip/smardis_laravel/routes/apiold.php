<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SmardisApiController;
Route::match(['get','post','options'], '/smardis', [SmardisApiController::class, 'handle']);
// Compatibilité ancienne URL si un vieux JS appelle /api.php depuis Laravel
Route::match(['get','post','options'], '/api.php', [SmardisApiController::class, 'handle']);
