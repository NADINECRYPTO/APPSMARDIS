<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

Route::match(['GET','POST'], '/smardis', function (Request $request) {

    $action = $request->get('action');

    if ($action === 'ping') {
        return response()->json([
            'success' => true,
            'message' => 'MySQL OK'
        ]);
    }

    if ($action === 'login') {

        $email = trim($request->get('email'));
        $password = trim($request->get('password'));

        $user = DB::table('smardis_users')
            ->where('email', $email)
            ->first();

        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'Utilisateur introuvable'
            ]);
        }

        if ($user->password != $password) {
            return response()->json([
                'success' => false,
                'error' => 'Mot de passe incorrect'
            ]);
        }

        DB::table('smardis_users')
            ->where('id', $user->id)
            ->update([
                'last_login_at' => now(),
                'updated_at' => now()
            ]);

        return response()->json([
            'success' => true,
            'user' => $user
        ]);
    }

    if ($action === 'sync_pull') {

        $rows = DB::table('smardis_sync_store')->get();

        $data = [];

        foreach($rows as $r){
            $data[$r->sync_key] = json_decode($r->sync_value, true);
        }

        return response()->json([
            'success' => true,
            'data' => $data
        ]);
    }

    if ($action === 'sync_push') {

        $body = $request->all();

        DB::table('smardis_sync_store')->updateOrInsert(
            ['sync_key' => $body['key']],
            [
                'sync_value' => json_encode($body['data']),
                'updated_at' => now()
            ]
        );

        return response()->json([
            'success' => true
        ]);
    }

    return response()->json([
        'success' => false,
        'error' => 'Action API inconnue: ' . $action
    ]);
});
