<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('erp');
});

Route::get('/erp', function () {
    return view('erp');
});

Route::get('/boutique', function () {
    return view('boutique');
});

Route::get('/boutique.html', function () {
    return view('boutique');
});