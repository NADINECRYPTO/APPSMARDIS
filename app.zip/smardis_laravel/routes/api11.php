<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

Route::match(['GET', 'POST'], '/smardis', function (Request $request) {
    $action = $request->query('action', $request->input('action'));

    try {
        if ($action === 'ping') {
            DB::connection()->getPdo();
            return response()->json([
                'success' => true,
                'message' => 'SMARDIS API + MySQL OK',
                'time' => now()->toDateTimeString(),
            ]);
        }

        if ($action === 'sync_pull') {
            DB::statement("CREATE TABLE IF NOT EXISTS smardis_sync_store (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                sync_key VARCHAR(191) NOT NULL UNIQUE,
                sync_value LONGTEXT NULL,
                created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            $rows = DB::table('smardis_sync_store')->get();
            $data = [];

            foreach ($rows as $row) {
                $decoded = json_decode($row->sync_value, true);
                $data[$row->sync_key] = $decoded === null ? [] : $decoded;
            }

            return response()->json([
                'success' => true,
                'data' => $data,
                'count' => count($data),
            ]);
        }

        if ($action === 'sync_push') {
            DB::statement("CREATE TABLE IF NOT EXISTS smardis_sync_store (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                sync_key VARCHAR(191) NOT NULL UNIQUE,
                sync_value LONGTEXT NULL,
                created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            $payload = $request->json()->all();
            if (!$payload) {
                $payload = $request->all();
            }

            $key = $payload['key'] ?? null;
            $data = $payload['data'] ?? null;

            if (!$key) {
                return response()->json([
                    'success' => false,
                    'error' => 'sync_key manquant',
                ], 422);
            }

            // Ne pas synchroniser les sessions locales navigateur.
            if (str_contains((string)$key, '_s') || str_contains((string)$key, 'session')) {
                return response()->json([
                    'success' => true,
                    'ignored' => true,
                ]);
            }

            DB::table('smardis_sync_store')->updateOrInsert(
                ['sync_key' => $key],
                [
                    'sync_value' => json_encode($data, JSON_UNESCAPED_UNICODE),
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );

            return response()->json([
                'success' => true,
                'key' => $key,
            ]);
        }

        if ($action === 'sync_clear_browser_warning') {
            return response()->json([
                'success' => true,
                'message' => 'Videz le localStorage dans chaque navigateur après activation MySQL.',
            ]);
        }

        return response()->json([
            'success' => false,
            'error' => 'Action API inconnue: ' . $action,
        ], 404);
    } catch (Throwable $e) {
        return response()->json([
            'success' => false,
            'error' => 'Erreur API/MySQL: ' . $e->getMessage(),
        ], 500);
    }
});
