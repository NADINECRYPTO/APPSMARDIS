<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/*
|--------------------------------------------------------------------------
| SMARDIS API MySQL Multi-Utilisateur
|--------------------------------------------------------------------------
| Actions:
| ping, login, logout, current_user
| users_list, user_create, user_update, user_delete
| sync_pull, sync_push
*/

function smardis_json($data, $code = 200) {
    return response()->json($data, $code);
}

function smardis_table_exists($table) {
    try {
        return DB::select("SHOW TABLES LIKE ?", [$table]) ? true : false;
    } catch (\Throwable $e) {
        return false;
    }
}

function smardis_get_user_by_token($token) {
    if (!$token) return null;
    try {
        $session = DB::table('smardis_user_sessions')
            ->where('token', $token)
            ->where('expires_at', '>', now())
            ->first();

        if (!$session) return null;

        return DB::table('smardis_users')
            ->where('id', $session->user_id)
            ->where('is_active', 1)
            ->first();
    } catch (\Throwable $e) {
        return null;
    }
}

function smardis_password_ok($plain, $stored) {
    if (!$stored) return false;

    // Mot de passe hashé Laravel/PHP
    if (Str::startsWith($stored, ['$2y$', '$2a$', '$argon2i$', '$argon2id$'])) {
        return password_verify($plain, $stored);
    }

    // Compatibilité ancien système : mot de passe texte simple
    return hash_equals((string)$stored, (string)$plain);
}

function smardis_can_manage_users($user) {
    if (!$user) return false;
    return in_array($user->role, ['admin', 'manager', 'responsable'], true);
}

Route::match(['GET','POST'], '/smardis', function (Request $request) {

    $action = $request->get('action');

    try {

        if ($action === 'ping') {
            DB::connection()->getPdo();

            return smardis_json([
                'success' => true,
                'message' => 'SMARDIS API/MySQL OK',
                'time' => now()->toDateTimeString()
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | LOGIN MULTI-UTILISATEUR
        |--------------------------------------------------------------------------
        */
        if ($action === 'login') {

            $email = trim((string)$request->get('email', ''));
            $password = (string)$request->get('password', '');

            if ($email === '' || $password === '') {
                return smardis_json([
                    'success' => false,
                    'error' => 'Email et mot de passe obligatoires'
                ], 422);
            }

            $user = DB::table('smardis_users')
                ->where('email', $email)
                ->where('is_active', 1)
                ->first();

            if (!$user || !smardis_password_ok($password, $user->password)) {
                return smardis_json([
                    'success' => false,
                    'error' => 'Email ou mot de passe incorrect'
                ], 401);
            }

            $token = bin2hex(random_bytes(40));

            DB::table('smardis_user_sessions')->insert([
                'user_id' => $user->id,
                'token' => $token,
                'ip_address' => $request->ip(),
                'user_agent' => substr((string)$request->userAgent(), 0, 500),
                'expires_at' => now()->addHours(12),
                'created_at' => now(),
                'updated_at' => now()
            ]);

            DB::table('smardis_users')
                ->where('id', $user->id)
                ->update([
                    'last_login_at' => now(),
                    'updated_at' => now()
                ]);

            unset($user->password);

            return smardis_json([
                'success' => true,
                'token' => $token,
                'user' => $user
            ]);
        }

        if ($action === 'logout') {
            $token = $request->bearerToken() ?: $request->get('token');
            if ($token) {
                DB::table('smardis_user_sessions')->where('token', $token)->delete();
            }
            return smardis_json(['success' => true]);
        }

        if ($action === 'current_user') {
            $token = $request->bearerToken() ?: $request->get('token');
            $user = smardis_get_user_by_token($token);

            if (!$user) {
                return smardis_json(['success' => false, 'error' => 'Session expirée'], 401);
            }

            unset($user->password);
            return smardis_json(['success' => true, 'user' => $user]);
        }

        /*
        |--------------------------------------------------------------------------
        | UTILISATEURS MULTIPLES
        |--------------------------------------------------------------------------
        */
        if ($action === 'users_list') {
            $token = $request->bearerToken() ?: $request->get('token');
            $authUser = smardis_get_user_by_token($token);

            if (!smardis_can_manage_users($authUser)) {
                return smardis_json(['success' => false, 'error' => 'Accès refusé'], 403);
            }

            $users = DB::table('smardis_users')
                ->select('id','name','email','role','warehouse_id','store_id','is_active','last_login_at','created_at','updated_at')
                ->orderBy('id','desc')
                ->get();

            return smardis_json(['success' => true, 'users' => $users]);
        }

        if ($action === 'user_create') {
            $token = $request->bearerToken() ?: $request->get('token');
            $authUser = smardis_get_user_by_token($token);

            if (!smardis_can_manage_users($authUser)) {
                return smardis_json(['success' => false, 'error' => 'Accès refusé'], 403);
            }

            $email = trim((string)$request->get('email', ''));
            $password = (string)$request->get('password', '');

            if ($email === '' || $password === '') {
                return smardis_json(['success' => false, 'error' => 'Email et mot de passe obligatoires'], 422);
            }

            $exists = DB::table('smardis_users')->where('email', $email)->exists();
            if ($exists) {
                return smardis_json(['success' => false, 'error' => 'Cet email existe déjà'], 409);
            }

            $id = DB::table('smardis_users')->insertGetId([
                'name' => $request->get('name', $email),
                'email' => $email,
                'password' => password_hash($password, PASSWORD_BCRYPT),
                'role' => $request->get('role', 'vendeur'),
                'warehouse_id' => $request->get('warehouse_id'),
                'store_id' => $request->get('store_id'),
                'is_active' => (int)$request->get('is_active', 1),
                'created_by' => $authUser ? $authUser->id : null,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            return smardis_json(['success' => true, 'id' => $id]);
        }

        if ($action === 'user_update') {
            $token = $request->bearerToken() ?: $request->get('token');
            $authUser = smardis_get_user_by_token($token);

            if (!smardis_can_manage_users($authUser)) {
                return smardis_json(['success' => false, 'error' => 'Accès refusé'], 403);
            }

            $id = (int)$request->get('id');
            if (!$id) return smardis_json(['success'=>false,'error'=>'ID utilisateur obligatoire'], 422);

            $data = [
                'name' => $request->get('name'),
                'email' => $request->get('email'),
                'role' => $request->get('role'),
                'warehouse_id' => $request->get('warehouse_id'),
                'store_id' => $request->get('store_id'),
                'is_active' => (int)$request->get('is_active', 1),
                'updated_at' => now()
            ];

            $data = array_filter($data, fn($v) => $v !== null);

            if ($request->get('password')) {
                $data['password'] = password_hash((string)$request->get('password'), PASSWORD_BCRYPT);
            }

            DB::table('smardis_users')->where('id', $id)->update($data);

            return smardis_json(['success' => true]);
        }

        if ($action === 'user_delete') {
            $token = $request->bearerToken() ?: $request->get('token');
            $authUser = smardis_get_user_by_token($token);

            if (!smardis_can_manage_users($authUser)) {
                return smardis_json(['success' => false, 'error' => 'Accès refusé'], 403);
            }

            $id = (int)$request->get('id');
            if (!$id) return smardis_json(['success'=>false,'error'=>'ID utilisateur obligatoire'], 422);

            // Désactivation au lieu de suppression pour garder historique
            DB::table('smardis_users')->where('id', $id)->update([
                'is_active' => 0,
                'updated_at' => now()
            ]);

            return smardis_json(['success' => true]);
        }

        /*
        |--------------------------------------------------------------------------
        | SYNCHRONISATION GLOBALE ERP/BOUTIQUE
        |--------------------------------------------------------------------------
        | Ici on garde le principe actuel localStorage, mais MySQL devient la source
        | centrale. Tous les navigateurs utilisent les mêmes clés.
        */
        if ($action === 'sync_pull') {

            $rows = DB::table('smardis_sync_store')->get();

            $data = [];
            foreach ($rows as $row) {
                $key = $row->sync_key ?? $row->key ?? null;
                $value = $row->sync_value ?? $row->value ?? null;

                if ($key) {
                    $decoded = json_decode((string)$value, true);
                    $data[$key] = $decoded === null && $value !== 'null' ? $value : $decoded;
                }
            }

            return smardis_json([
                'success' => true,
                'data' => $data,
                'server_time' => now()->toDateTimeString()
            ]);
        }

        if ($action === 'sync_push') {

            $payloadKey = $request->get('key');
            $payloadData = $request->get('data');

            if (!$payloadKey) {
                return smardis_json(['success' => false, 'error' => 'sync key manquante'], 422);
            }

            $token = $request->bearerToken() ?: $request->get('token');
            $authUser = smardis_get_user_by_token($token);

            DB::table('smardis_sync_store')->updateOrInsert(
                ['sync_key' => $payloadKey],
                [
                    'sync_value' => json_encode($payloadData, JSON_UNESCAPED_UNICODE),
                    'updated_by' => $authUser ? $authUser->id : null,
                    'updated_at' => now()
                ]
            );

            return smardis_json([
                'success' => true,
                'key' => $payloadKey
            ]);
        }

        if ($action === 'sync_clear_key') {
            $token = $request->bearerToken() ?: $request->get('token');
            $authUser = smardis_get_user_by_token($token);

            if (!smardis_can_manage_users($authUser)) {
                return smardis_json(['success' => false, 'error' => 'Accès refusé'], 403);
            }

            DB::table('smardis_sync_store')->where('sync_key', $request->get('key'))->delete();
            return smardis_json(['success' => true]);
        }

        return smardis_json([
            'success' => false,
            'error' => 'Action API inconnue: '.$action
        ], 404);

    } catch (\Throwable $e) {
        return smardis_json([
            'success' => false,
            'error' => 'Erreur API/MySQL: '.$e->getMessage()
        ], 500);
    }
});
