<?php
header('Content-Type: text/html; charset=utf-8');
function badge($ok){return $ok?'<span style="color:#0a7d2b;font-weight:900">OK</span>':'<span style="color:#b00020;font-weight:900">ERREUR</span>';}
function box($h,$c){echo '<div class="box"><h2>'.$h.'</h2>'.$c.'</div>';}
echo '<!doctype html><html><head><meta charset="utf-8"><title>Diagnostic SMARDIS</title><style>body{font-family:Arial,sans-serif;background:#f6f7fb;margin:0;padding:25px;color:#1f2937}.box{background:white;border-radius:14px;padding:18px;margin:12px 0;box-shadow:0 4px 18px #0001}pre{background:#111827;color:#f9fafb;padding:12px;border-radius:10px;white-space:pre-wrap;overflow:auto}.btn{display:inline-block;background:#c9a84c;color:#0f1a45;padding:11px 16px;border-radius:10px;text-decoration:none;font-weight:900;margin:4px}</style></head><body><h1>Diagnostic SMARDIS — MySQL obligatoire</h1>';
box('1) PHP', 'Version: <b>'.htmlspecialchars(PHP_VERSION).'</b><br>PDO MySQL: '.badge(extension_loaded('pdo_mysql')));
if(!file_exists(__DIR__.'/config.php')){box('2) config.php', badge(false).' fichier absent'); exit('</body></html>');}
require_once __DIR__.'/config.php';
$conf='DB_HOST='.(defined('DB_HOST')?DB_HOST:'?')."\nDB_NAME=".(defined('DB_NAME')?DB_NAME:'?')."\nDB_USER=".(defined('DB_USER')?DB_USER:'?')."\nDB_PASS=********\nDB_CHARSET=".(defined('DB_CHARSET')?DB_CHARSET:'?');
box('2) Configuration lue', '<pre>'.htmlspecialchars($conf).'</pre>');
try{
 $pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 box('3) Connexion MySQL', badge(true).' Connexion réussie');
 $sqls=[
 "CREATE TABLE IF NOT EXISTS smardis_sync_store (key_name VARCHAR(80) NOT NULL PRIMARY KEY,json_data LONGTEXT NOT NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS smardis_users (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,name VARCHAR(255) NOT NULL,email VARCHAR(255) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,role VARCHAR(60) DEFAULT 'caissier',active TINYINT(1) DEFAULT 1,entrepot_id VARCHAR(50) DEFAULT NULL,store_id VARCHAR(50) DEFAULT NULL,phone VARCHAR(60) DEFAULT NULL,avatar VARCHAR(20) DEFAULT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS smardis_sessions (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id VARCHAR(50) NOT NULL,token VARCHAR(255) NOT NULL UNIQUE,user_data TEXT NULL,expires_at DATETIME NOT NULL,ip_address VARCHAR(45) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_token(token),INDEX idx_expires(expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
 "CREATE TABLE IF NOT EXISTS smardis_buyers (id VARCHAR(50) NOT NULL PRIMARY KEY,name VARCHAR(255) NOT NULL,email VARCHAR(255) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,phone VARCHAR(50),city VARCHAR(100),address TEXT,lat DECIMAL(10,7),lng DECIMAL(10,7),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
 ];
 foreach($sqls as $sql){$pdo->exec($sql);} 
 $seed=[['Admin Principal','admin@wwe.com','admin123','admin','👨‍💼'],['Karim Magasinier','stock@wwe.com','stock123','storekeeper','👨‍🔧'],['Caissier POS','caissier@wwe.com','caissier123','pos_user','💼'],['Administrateur SMARDIS','admin@smardis.ma','admin123','admin','👨‍💼']];
 $q=$pdo->prepare("INSERT INTO smardis_users (name,email,password,role,avatar,active) VALUES (?,?,?,?,?,1) ON DUPLICATE KEY UPDATE password=VALUES(password), role=VALUES(role), active=1");
 foreach($seed as $u){$q->execute($u);} 
 $pdo->prepare("INSERT INTO smardis_sync_store (key_name,json_data) VALUES ('wwe_cat5',?) ON DUPLICATE KEY UPDATE json_data=IF(json_data='[]' OR json_data='' OR json_data IS NULL, VALUES(json_data), json_data)")->execute([json_encode(['Épicerie','Céréales','Huile','Conserves','Boissons','Sucre','Farine','Légumineuses','Épices','Produits Laitiers'],JSON_UNESCAPED_UNICODE)]);
 $tables=['smardis_sync_store','smardis_users','smardis_sessions','smardis_buyers']; $html=''; foreach($tables as $t){$st=$pdo->prepare('SHOW TABLES LIKE ?');$st->execute([$t]);$html.='<div>'.$t.' : '.badge((bool)$st->fetchColumn()).'</div>';}
 box('4) Tables auto-réparées', $html);
 $users=$pdo->query('SELECT email,role,active FROM smardis_users ORDER BY id LIMIT 20')->fetchAll(); box('5) Utilisateurs ERP', '<pre>'.htmlspecialchars(print_r($users,true)).'</pre>');
 $ping=@file_get_contents((isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['SCRIPT_NAME']),'/\\').'/api.php?action=ping&v='.time());
 box('6) Test api.php?action=ping', '<pre>'.htmlspecialchars($ping ?: 'Aucune réponse API').'</pre>');
 echo '<div class="box"><a class="btn" href="index.html?v='.time().'">Ouvrir ERP</a><a class="btn" href="boutique.html?v='.time().'">Ouvrir Boutique</a><a class="btn" href="api.php?action=ping&v='.time().'">Tester API directe</a><p>Login test: <b>admin@wwe.com</b> / <b>admin123</b></p></div>';
}catch(Throwable $e){
 box('3) Connexion MySQL', badge(false).'<pre>'.htmlspecialchars($e->getMessage()).'</pre><p>Corrigez config.php ou ajoutez l’utilisateur MySQL à la base avec ALL PRIVILEGES dans cPanel.</p>');
}
echo '</body></html>';
?>