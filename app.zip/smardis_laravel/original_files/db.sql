-- =====================================================
--  SMARDIS — Base de données MySQL complète
--  Compatible MySQL 5.7+ / MariaDB 10.3+
--  Importez via cPanel > phpMyAdmin
-- =====================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;

-- ── COMPANY ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_company` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) DEFAULT 'SMARDIS',
  `slogan` VARCHAR(255) DEFAULT 'Spécialité vente produits gros alimentaires',
  `address` TEXT,
  `phone` VARCHAR(50),
  `email` VARCHAR(100),
  `ice` VARCHAR(50),
  `rc` VARCHAR(50),
  `if_num` VARCHAR(50),
  `currency` VARCHAR(10) DEFAULT 'DH',
  `default_tva` DECIMAL(5,2) DEFAULT 20.00,
  `logo` LONGTEXT,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `smardis_company` (`name`,`slogan`,`address`,`phone`,`email`,`currency`,`default_tva`) VALUES
('SMARDIS','Spécialité vente produits gros alimentaires','Casablanca, Maroc','+212 5 22 00 00 00','contact@smardis.ma','DH',20);

-- ── USERS (ERP) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_users` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(60) DEFAULT 'caissier',
  `active` TINYINT(1) DEFAULT 1,
  `entrepot_id` INT DEFAULT NULL,
  `store_id` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `smardis_users` (`name`,`email`,`password`,`role`) VALUES
('Administrateur','admin@smardis.ma','admin123','admin'),
('Vendeur Terrain','vendeur@smardis.ma','vendeur123','vendeur_terrain'),
('Magasinier','stock@smardis.ma','stock123','storekeeper'),
('Caissier POS','caissier@smardis.ma','caissier123','pos_user');

-- ── SESSIONS ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_sessions` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` VARCHAR(50) NOT NULL,
  `token` VARCHAR(255) UNIQUE NOT NULL,
  `user_data` TEXT NULL,
  `expires_at` DATETIME NOT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── BUYERS (Boutique clients) ─────────────────────
CREATE TABLE IF NOT EXISTS `smardis_buyers` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50),
  `city` VARCHAR(100),
  `address` TEXT,
  `lat` DECIMAL(10,7),
  `lng` DECIMAL(10,7),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── CATEGORIES ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_categories` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) UNIQUE NOT NULL,
  `icon` VARCHAR(100) DEFAULT 'fa-tag',
  `color` VARCHAR(20) DEFAULT '#C9A84C',
  `sort_order` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `smardis_categories` (`name`,`icon`,`color`,`sort_order`) VALUES
('Épicerie','fa-shopping-basket','#C9A84C',1),
('Céréales','fa-seedling','#CA8A04',2),
('Huile','fa-oil-can','#D97706',3),
('Conserves','fa-box','#6366F1',4),
('Boissons','fa-glass-martini','#0EA5E9',5),
('Sucre','fa-cube','#F43F5E',6),
('Farine','fa-bread-slice','#A18D5A',7),
('Légumineuses','fa-leaf','#16A34A',8),
('Épices','fa-pepper-hot','#EF4444',9),
('Produits Laitiers','fa-cheese','#3B82F6',10),
('Hygiène','fa-soap','#7C3AED',11),
('Surgelés','fa-snowflake','#06B6D4',12);

-- ── ENTREPOTS ────────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_entrepots` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `address` TEXT,
  `zone_geo` VARCHAR(255),
  `phone` VARCHAR(50),
  `lat` DECIMAL(10,7),
  `lng` DECIMAL(10,7),
  `color` VARCHAR(20) DEFAULT '#1B2A6B',
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `smardis_entrepots` (`name`,`address`,`zone_geo`,`lat`,`lng`) VALUES
('Dépôt Principal','Casablanca, Maroc','Casablanca',33.5731,-7.5898);

-- ── STORES (POS) ─────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_stores` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `city` VARCHAR(100),
  `address` TEXT,
  `phone` VARCHAR(50),
  `entrepot_id` INT,
  `user_id` INT,
  `lat` DECIMAL(10,7),
  `lng` DECIMAL(10,7),
  `color` VARCHAR(20) DEFAULT '#1B2A6B',
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`entrepot_id`) REFERENCES `smardis_entrepots`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── PRODUCTS ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_products` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(100) UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(255),
  `description` TEXT,
  `price` DECIMAL(10,2) DEFAULT 0,
  `purchase_price` DECIMAL(10,2) DEFAULT 0,
  `tva_rate` DECIMAL(5,2) DEFAULT 20.00,
  `stock` INT DEFAULT 0,
  `min_stock` INT DEFAULT 0,
  `unit` VARCHAR(50) DEFAULT 'piece',
  `photo` LONGTEXT,
  `online` TINYINT(1) DEFAULT 0,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── CLIENTS ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_clients` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255),
  `phone` VARCHAR(50),
  `address` TEXT,
  `city` VARCHAR(100),
  `ice` VARCHAR(50),
  `credit_limit` DECIMAL(10,2) DEFAULT 0,
  `balance` DECIMAL(10,2) DEFAULT 0,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── SUPPLIERS ────────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_suppliers` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255),
  `phone` VARCHAR(50),
  `address` TEXT,
  `ice` VARCHAR(50),
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── DOCUMENTS (Ventes, BL, Devis...) ─────────────
CREATE TABLE IF NOT EXISTS `smardis_documents` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `type` VARCHAR(50) NOT NULL,
  `number` VARCHAR(100),
  `client_id` INT,
  `client_name` VARCHAR(255),
  `date` DATE,
  `status` VARCHAR(50) DEFAULT 'brouillon',
  `lines` JSON,
  `total_ht` DECIMAL(10,2) DEFAULT 0,
  `total_tva` DECIMAL(10,2) DEFAULT 0,
  `total_ttc` DECIMAL(10,2) DEFAULT 0,
  `notes` TEXT,
  `created_by` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── ONLINE ORDERS (Boutique) ─────────────────────
CREATE TABLE IF NOT EXISTS `smardis_online_orders` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `buyer_id` VARCHAR(50),
  `buyer_name` VARCHAR(255),
  `buyer_email` VARCHAR(255),
  `buyer_phone` VARCHAR(50),
  `buyer_city` VARCHAR(100),
  `buyer_address` TEXT,
  `buyer_lat` DECIMAL(10,7),
  `buyer_lng` DECIMAL(10,7),
  `lines` JSON NOT NULL,
  `total` DECIMAL(10,2) DEFAULT 0,
  `pay_mode` VARCHAR(50) DEFAULT 'livraison',
  `notes` TEXT,
  `status` VARCHAR(50) DEFAULT 'nouvelle',
  `assigned_store_id` VARCHAR(50),
  `assigned_store_name` VARCHAR(255),
  `assigned_store_city` VARCHAR(100),
  `assigned_entrepot_id` INT,
  `distance_km` DECIMAL(8,2),
  `prepared_by` VARCHAR(255),
  `prepared_at` DATETIME,
  `delivered_by` VARCHAR(255),
  `delivered_at` DATETIME,
  `rejected_by` VARCHAR(255),
  `rejected_at` DATETIME,
  `pos_sale_id` VARCHAR(50),
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── POS SALES ────────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_pos_sales` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `type` VARCHAR(50) DEFAULT 'caisse',
  `order_id` VARCHAR(50),
  `store_id` VARCHAR(50),
  `store_name` VARCHAR(255),
  `client_id` INT,
  `client_name` VARCHAR(255),
  `client_phone` VARCHAR(50),
  `client_city` VARCHAR(100),
  `client_address` TEXT,
  `lines` JSON NOT NULL,
  `total_ht` DECIMAL(10,2) DEFAULT 0,
  `tva` DECIMAL(10,2) DEFAULT 0,
  `total_ttc` DECIMAL(10,2) DEFAULT 0,
  `payments` JSON,
  `pay_mode` VARCHAR(50),
  `amount_paid` DECIMAL(10,2) DEFAULT 0,
  `amount_due` DECIMAL(10,2) DEFAULT 0,
  `rendu` DECIMAL(10,2) DEFAULT 0,
  `status` VARCHAR(50) DEFAULT 'valide',
  `notes` TEXT,
  `by` VARCHAR(255),
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `delivered_at` DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── STOCK MOVEMENTS ──────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_stock_movements` (
  `id` VARCHAR(100) NOT NULL PRIMARY KEY,
  `type` ENUM('entree','sortie','transfert','ajustement') NOT NULL,
  `product_id` INT,
  `product_name` VARCHAR(255),
  `qty` INT NOT NULL,
  `reason` TEXT,
  `entrepot_id` INT,
  `store_id` VARCHAR(50),
  `order_id` VARCHAR(50),
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `by` VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── NOTIFICATIONS ────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_notifications` (
  `id` BIGINT NOT NULL PRIMARY KEY,
  `msg` TEXT NOT NULL,
  `doc_id` VARCHAR(50),
  `type` VARCHAR(50) DEFAULT 'info',
  `read_status` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── REGLEMENTS ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_reglements` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `document_id` VARCHAR(50),
  `client_id` INT,
  `client_name` VARCHAR(255),
  `amount` DECIMAL(10,2) DEFAULT 0,
  `method` VARCHAR(50),
  `date` DATE,
  `notes` TEXT,
  `created_by` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── TRANSFERTS ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_transferts` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `from_entrepot_id` INT,
  `to_entrepot_id` INT,
  `lines` JSON,
  `status` VARCHAR(50) DEFAULT 'en_attente',
  `notes` TEXT,
  `created_by` VARCHAR(255),
  `validated_by` VARCHAR(255),
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── POS RETOURS ──────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_pos_retours` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `sale_id` VARCHAR(50),
  `store_id` VARCHAR(50),
  `lines` JSON,
  `total` DECIMAL(10,2) DEFAULT 0,
  `status` VARCHAR(50) DEFAULT 'en_attente',
  `notes` TEXT,
  `created_by` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── PROMOTIONS ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `smardis_promotions` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255),
  `product_id` INT,
  `discount_type` VARCHAR(20) DEFAULT 'percent',
  `discount_value` DECIMAL(10,2),
  `start_date` DATE,
  `end_date` DATE,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── INDEX pour performances ───────────────────────
CREATE INDEX idx_products_category ON smardis_products(category);
CREATE INDEX idx_products_online ON smardis_products(online, active);
CREATE INDEX idx_orders_status ON smardis_online_orders(status);
CREATE INDEX idx_orders_store ON smardis_online_orders(assigned_store_id);
CREATE INDEX idx_orders_buyer ON smardis_online_orders(buyer_id);
CREATE INDEX idx_pos_sales_store ON smardis_pos_sales(store_id);
CREATE INDEX idx_pos_sales_date ON smardis_pos_sales(date);
CREATE INDEX idx_notifs_read ON smardis_notifications(read_status);
CREATE INDEX idx_stock_product ON smardis_stock_movements(product_id);

-- =====================================================
--  FIN — Base de données SMARDIS créée avec succès
-- =====================================================
