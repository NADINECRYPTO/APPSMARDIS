<?php
/**
 * SMARDIS — Configuration Hosting Web / cPanel
 * IMPORTANT: Modifiez seulement les 4 lignes DB_* avec les infos de votre hébergeur.
 */

// ── Base de données cPanel / Hosting ──────────────────────────
define('DB_HOST',    'localhost');          // Souvent: localhost. Sinon demandez à votre hébergeur.
define('DB_NAME',    'smardy78_smardis_db'); // Exemple: moncompte_smardis_db
define('DB_USER',    'smardy78_admin'); // Exemple: moncompte_smardis_user
define('DB_PASS',    'Faicel0771380303@');
define('DB_CHARSET', 'utf8mb4');

// ── Application ───────────────────────────────────────────────
define('APP_SECRET',  'changez_cette_cle_unique_smardis_2026');
define('APP_VERSION', '1.0.0');
define('APP_NAME',    'SMARDIS');

// Pour éviter les blocages CORS au début. Après test, vous pouvez mettre: https://votre-domaine.com
define('ALLOWED_ORIGIN', '*');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error'   => 'Connexion MySQL impossible',
                'detail'  => $e->getMessage(),
                'fix'     => 'Vérifiez DB_HOST, DB_NAME, DB_USER, DB_PASS dans config.php et les privilèges MySQL dans cPanel.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    return $pdo;
}
