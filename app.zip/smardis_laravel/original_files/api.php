<?php
/**
 * SMARDIS — API REST v2.2 FIX MULTI-USER + SYNC SQL
 * Corrige: sessions schema, roles ERP, sauvegarde sync_store, catégories/produits boutique.
 */
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Token');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
$input=json_decode(file_get_contents('php://input'),true); if(!is_array($input)) $input=[];
$action=$_GET['action'] ?? $input['action'] ?? '';
$token=$_SERVER['HTTP_X_TOKEN'] ?? $input['token'] ?? ($_GET['token'] ?? '');
function respond($d,$c=200){http_response_code($c);echo json_encode($d,JSON_UNESCAPED_UNICODE);exit;}
function error($m,$c=400,$extra=[]){respond(array_merge(['success'=>false,'error'=>$m],$extra),$c);} 
function ok($d=null,$m='ok'){respond(['success'=>true,'message'=>$m,'data'=>$d]);}
try{$db=getDB();$db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);}catch(Exception $e){error('Connexion DB impossible: '.$e->getMessage(),500);} 
function table_exists($db,$t){try{$s=$db->prepare("SHOW TABLES LIKE ?");$s->execute([$t]);return (bool)$s->fetchColumn();}catch(Exception $e){return false;}}
function col_exists($db,$t,$c){try{$s=$db->prepare("SHOW COLUMNS FROM `$t` LIKE ?");$s->execute([$c]);return (bool)$s->fetchColumn();}catch(Exception $e){return false;}}
function ensure_schema($db){
  $db->exec("CREATE TABLE IF NOT EXISTS `smardis_sync_store` (`key_name` VARCHAR(80) NOT NULL PRIMARY KEY,`json_data` LONGTEXT NOT NULL,`updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $db->exec("CREATE TABLE IF NOT EXISTS `smardis_users` (`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,`name` VARCHAR(255) NOT NULL,`email` VARCHAR(255) UNIQUE NOT NULL,`password` VARCHAR(255) NOT NULL,`role` VARCHAR(60) DEFAULT 'caissier',`active` TINYINT(1) DEFAULT 1,`entrepot_id` VARCHAR(50) DEFAULT NULL,`store_id` VARCHAR(50) DEFAULT NULL,`phone` VARCHAR(60) DEFAULT NULL,`avatar` VARCHAR(20) DEFAULT NULL,`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  if(table_exists($db,'smardis_users')){
    try{$db->exec("ALTER TABLE smardis_users MODIFY role VARCHAR(60) DEFAULT 'caissier'");}catch(Exception $e){}
    foreach(['entrepot_id'=>'VARCHAR(50) DEFAULT NULL','store_id'=>'VARCHAR(50) DEFAULT NULL','phone'=>'VARCHAR(60) DEFAULT NULL','avatar'=>'VARCHAR(20) DEFAULT NULL','active'=>'TINYINT(1) DEFAULT 1'] as $c=>$def){if(!col_exists($db,'smardis_users',$c)){try{$db->exec("ALTER TABLE smardis_users ADD `$c` $def");}catch(Exception $e){}}}
  }
  $db->exec("CREATE TABLE IF NOT EXISTS `smardis_sessions` (`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,`user_id` VARCHAR(50) NOT NULL,`token` VARCHAR(255) NOT NULL UNIQUE,`user_data` TEXT NULL,`expires_at` DATETIME NOT NULL,`ip_address` VARCHAR(45) NULL,`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_token (`token`),INDEX idx_expires (`expires_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  if(table_exists($db,'smardis_sessions')){
    try{$db->exec("ALTER TABLE smardis_sessions MODIFY user_id VARCHAR(50) NOT NULL");}catch(Exception $e){}
    if(!col_exists($db,'smardis_sessions','user_data')){try{$db->exec("ALTER TABLE smardis_sessions ADD user_data TEXT NULL AFTER token");}catch(Exception $e){}}
    if(!col_exists($db,'smardis_sessions','ip_address')){try{$db->exec("ALTER TABLE smardis_sessions ADD ip_address VARCHAR(45) NULL");}catch(Exception $e){}}
  }
  $db->exec("CREATE TABLE IF NOT EXISTS `smardis_buyers` (`id` VARCHAR(50) NOT NULL PRIMARY KEY,`name` VARCHAR(255) NOT NULL,`email` VARCHAR(255) UNIQUE NOT NULL,`password` VARCHAR(255) NOT NULL,`phone` VARCHAR(50),`city` VARCHAR(100),`address` TEXT,`lat` DECIMAL(10,7),`lng` DECIMAL(10,7),`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  // Créer les utilisateurs ERP indispensables s'ils n'existent pas
  $seed=[['Admin Principal','admin@wwe.com','admin123','admin','👨‍💼'],['Sarah Vendeuse','vendeur@wwe.com','vendeur123','sales_agent','👩‍💼'],['Karim Magasinier','stock@wwe.com','stock123','storekeeper','👨‍🔧'],['Nadia Comptable','compta@wwe.com','compta123','comptable','👩‍💻'],['Hassan Livreur','livreur@wwe.com','livreur123','livreur','🚚'],['Yasmine Caissiere','caissier@wwe.com','caissier123','caissier','💼'],['Omar Vendeur Terrain','vt@wwe.com','vendeur123','vendeur_terrain','🏪'],['Administrateur SMARDIS','admin@smardis.ma','admin123','admin','👨‍💼'],['Magasinier SMARDIS','stock@smardis.ma','stock123','storekeeper','👨‍🔧'],['Caissier POS','caissier@smardis.ma','caissier123','pos_user','💼']];
  $q=$db->prepare("INSERT INTO smardis_users (name,email,password,role,avatar,active) VALUES (?,?,?,?,?,1) ON DUPLICATE KEY UPDATE role=VALUES(role), active=1");
  foreach($seed as $u){try{$q->execute($u);}catch(Exception $e){}}
}
ensure_schema($db);
function get_sync($db,$key,$fb=[]){try{$s=$db->prepare('SELECT json_data FROM smardis_sync_store WHERE key_name=?');$s->execute([$key]);$r=$s->fetchColumn();return $r?json_decode($r,true):$fb;}catch(Exception $e){return $fb;}}
function set_sync($db,$key,$data){$json=json_encode($data,JSON_UNESCAPED_UNICODE);if($json===false) throw new Exception('JSON invalide '.$key);$s=$db->prepare('INSERT INTO smardis_sync_store (key_name,json_data,updated_at) VALUES (?,?,NOW()) ON DUPLICATE KEY UPDATE json_data=VALUES(json_data),updated_at=NOW()');$s->execute([$key,$json]);}

function sync_users_to_table($db,$users){
  if(!is_array($users)) return 0;
  ensure_schema($db);
  $count=0;
  $sql="INSERT INTO smardis_users (id,name,email,password,role,active,entrepot_id,store_id,phone,avatar)
        VALUES (?,?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
          name=VALUES(name), password=VALUES(password), role=VALUES(role), active=VALUES(active),
          entrepot_id=VALUES(entrepot_id), store_id=VALUES(store_id), phone=VALUES(phone), avatar=VALUES(avatar)";
  $q=$db->prepare($sql);
  foreach($users as $u){
    if(!is_array($u)) continue;
    $email=trim($u['email']??'');
    if(!$email) continue;
    $id=$u['id']??null;
    if(!is_numeric($id)) $id=null;
    $name=$u['name']??($u['nom']??'Utilisateur');
    $pwd=$u['password']??($u['pwd']??'');
    if($pwd==='') $pwd='123456';
    $role=$u['role']??'caissier';
    $active=(($u['active']??1)!==false && ($u['active']??1)!=0)?1:0;
    $ent=$u['entrepot_id']??($u['warehouse_id']??null);
    $store=$u['store_id']??null;
    $phone=$u['phone']??($u['tel']??null);
    $avatar=$u['avatar']??'👤';
    try{$q->execute([$id,$name,$email,$pwd,$role,$active,$ent,$store,$phone,$avatar]);$count++;}catch(Exception $e){}
  }
  return $count;
}
function table_users_to_sync($db){
  try{
    $users=$db->query('SELECT id,name,email,password,role,active,entrepot_id,store_id,phone,avatar FROM smardis_users ORDER BY id')->fetchAll();
    return array_map(function($u){$u['active']=(bool)$u['active']; if(empty($u['avatar']))$u['avatar']='👤'; return $u;},$users?:[]);
  }catch(Exception $e){return [];}
}
function seed_sync_from_tables($db){
  $cnt=(int)$db->query('SELECT COUNT(*) FROM smardis_sync_store')->fetchColumn();
  // ✅ Multi-appareil: si l'ERP a créé des utilisateurs dans wwe_u5, on les écrit d'abord dans la table SQL.
  $localUsers=get_sync($db,'wwe_u5',[]);
  if(is_array($localUsers) && count($localUsers)>0){ sync_users_to_table($db,$localUsers); }
  // Toujours publier les utilisateurs depuis SQL vers sync_store pour tous les appareils.
  $users=table_users_to_sync($db);
  if($users){set_sync($db,'wwe_u5',$users);}
  // Si le sync est vide ou catégories manquantes, alimenter catégories alimentaires.
  $cats=get_sync($db,'wwe_cat5',null);
  if(!$cats || (is_array($cats)&&count($cats)==0)) set_sync($db,'wwe_cat5',['Épicerie','Céréales','Huile','Conserves','Boissons','Sucre','Farine','Légumineuses','Épices','Produits Laitiers','Hygiène','Surgelés']);
  // Si table produits existe et wwe_p5 absent, transférer vers format ERP.
  $prods=get_sync($db,'wwe_p5',null);
  if((!$prods || count($prods)==0) && table_exists($db,'smardis_products')){try{$rows=$db->query('SELECT id,code,name,category,description,price,purchase_price,tva_rate,stock,min_stock,unit,photo,online,active FROM smardis_products ORDER BY id')->fetchAll(); if($rows){$arr=[]; foreach($rows as $r){$arr[]=['id'=>$r['id'],'code'=>$r['code'],'name'=>$r['name'],'category'=>$r['category'],'description'=>$r['description'],'price'=>(float)$r['price'],'buy'=>(float)$r['purchase_price'],'tva'=>(float)$r['tva_rate'],'stock'=>(float)$r['stock'],'min'=>(float)$r['min_stock'],'unit'=>$r['unit'],'image'=>$r['photo'],'photo'=>$r['photo'],'online'=>(bool)$r['online'],'active'=>(bool)$r['active']];} set_sync($db,'wwe_p5',$arr);}}catch(Exception $e){}}
}
seed_sync_from_tables($db);
function findUser($db,$email,$password){
  $users=get_sync($db,'wwe_u5',[]); if(is_array($users)){foreach($users as $u){if(!is_array($u))continue; $active=($u['active']??true)!==false && ($u['active']??1)!=0; if($active && strtolower($u['email']??'')===strtolower($email)){ $p=$u['password']??($u['pwd']??''); if($p===$password || (is_string($p)&&password_verify($password,$p))) return $u; }}}
  try{$s=$db->prepare('SELECT * FROM smardis_users WHERE LOWER(email)=LOWER(?) AND active=1 LIMIT 1');$s->execute([$email]);$u=$s->fetch(); if($u){$p=$u['password']; if($p===$password || password_verify($password,$p)) return $u;}}catch(Exception $e){}
  return null;
}
if($action==='ping'){ok(['php'=>PHP_VERSION,'mysql'=>true,'sync_store_keys'=>(int)$db->query('SELECT COUNT(*) FROM smardis_sync_store')->fetchColumn(),'time'=>time()]);}
if($action==='login'){
  $email=trim($input['email']??'');$password=trim($input['password']??''); if(!$email||!$password)error('Email et mot de passe requis');
  try{$db->exec('DELETE FROM smardis_sessions WHERE expires_at < NOW()');}catch(Exception $e){}
  $user=findUser($db,$email,$password); if(!$user)error('Email ou mot de passe incorrect',401);
  $tok=bin2hex(random_bytes(32));$expires=date('Y-m-d H:i:s',strtotime('+8 hours'));$uid=(string)($user['id']??uniqid());
  $ud=['id'=>$uid,'name'=>$user['name']??'Utilisateur','email'=>$user['email']??$email,'role'=>$user['role']??'admin','avatar'=>$user['avatar']??'👤','active'=>true];
  $db->prepare('INSERT INTO smardis_sessions (user_id,token,user_data,expires_at,ip_address) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE user_data=VALUES(user_data),expires_at=VALUES(expires_at)')->execute([$uid,$tok,json_encode($ud,JSON_UNESCAPED_UNICODE),$expires,$_SERVER['REMOTE_ADDR']??'']);
  unset($user['password'],$user['pwd']); ok(['user'=>array_merge($user,$ud),'token'=>$tok,'expires_at'=>$expires],'Connexion réussie');
}
if($action==='verify_token'){$token=$token?:''; if(!$token)error('Token manquant',401);$s=$db->prepare('SELECT * FROM smardis_sessions WHERE token=? AND expires_at>NOW() LIMIT 1');$s->execute([$token]);$sess=$s->fetch(); if(!$sess)error('Session expirée',401);$new=date('Y-m-d H:i:s',strtotime('+8 hours'));$db->prepare('UPDATE smardis_sessions SET expires_at=? WHERE token=?')->execute([$new,$token]);ok(['user'=>json_decode($sess['user_data']?:'{}',true),'expires_at'=>$new]);}
if($action==='logout'){if($token){try{$db->prepare('DELETE FROM smardis_sessions WHERE token=?')->execute([$token]);}catch(Exception $e){}} ok(null,'Déconnecté');}
if($action==='sync_pull'){seed_sync_from_tables($db);$rows=$db->query('SELECT key_name,json_data FROM smardis_sync_store ORDER BY updated_at DESC')->fetchAll();$out=[];foreach($rows as $r){$out[$r['key_name']]=json_decode($r['json_data'],true);}respond(['success'=>true,'data'=>$out,'count'=>count($out),'time'=>time()]);}
if($action==='sync_push'){$key=$input['key']??''; if(!$key||!preg_match('/^wwe_[a-zA-Z0-9_]+$/',$key))error('Clé invalide: '.$key); if($key==='wwe_s5')ok(['key'=>$key,'skipped'=>true],'session ignorée'); $data=array_key_exists('data',$input)?$input['data']:[]; if($key==='wwe_u5'){ $n=sync_users_to_table($db,$data); $data=table_users_to_sync($db); set_sync($db,$key,$data); ok(['key'=>$key,'users_saved'=>$n,'rows'=>count($data),'time'=>time()],'Utilisateurs enregistrés SQL'); } set_sync($db,$key,$data); ok(['key'=>$key,'rows'=>is_array($data)?count($data):1,'time'=>time()],'Enregistré SQL');}
if($action==='sync_push_bulk'){$items=$input['items']??[]; if(!is_array($items))error('items invalide');$n=0;foreach($items as $key=>$data){if(preg_match('/^wwe_[a-zA-Z0-9_]+$/',$key)&&$key!=='wwe_s5'){set_sync($db,$key,$data);$n++;}}ok(['saved'=>$n]);}
if($action==='delete_key'){$key=$input['key']??''; if($key!=='wwe_s5')error('Suppression non autorisée');$db->prepare('DELETE FROM smardis_sync_store WHERE key_name=?')->execute([$key]);ok(null,'Clé supprimée');}
if($action==='buyer_login'){$email=$input['email']??'';$password=$input['password']??'';foreach(get_sync($db,'wwe_buyers1',[]) as $b){$p=$b['password']??($b['pwd']??''); if(($b['email']??'')===$email&&($p===$password||password_verify($password,$p))){unset($b['password'],$b['pwd']);ok(['buyer'=>$b]);}} try{$s=$db->prepare('SELECT * FROM smardis_buyers WHERE email=? LIMIT 1');$s->execute([$email]);$b=$s->fetch();if($b&&($b['password']===$password||password_verify($password,$b['password']))){unset($b['password']);ok(['buyer'=>$b]);}}catch(Exception $e){} error('Email ou mot de passe incorrect',401);}
if($action==='buyer_register'){$d=$input['data']??[]; if(empty($d['email'])||empty($d['name'])||empty($d['pwd']))error('Champs manquants');$id='BUY-'.time().rand(100,999);try{$db->prepare('INSERT INTO smardis_buyers (id,name,email,password,phone,city,address,lat,lng) VALUES (?,?,?,?,?,?,?,?,?)')->execute([$id,$d['name'],$d['email'],$d['pwd'],$d['phone']??null,$d['city']??null,$d['address']??null,$d['lat']??null,$d['lng']??null]);}catch(Exception $e){} $buyers=get_sync($db,'wwe_buyers1',[]);$nb=['id'=>$id,'name'=>$d['name'],'email'=>$d['email'],'password'=>$d['pwd'],'phone'=>$d['phone']??null,'city'=>$d['city']??null,'address'=>$d['address']??null,'lat'=>$d['lat']??null,'lng'=>$d['lng']??null];$buyers[]=$nb;set_sync($db,'wwe_buyers1',$buyers);unset($nb['password']);ok(['buyer'=>$nb],'Compte créé');}
if($action==='create_order'){$orders=get_sync($db,'wwe_orders1',[]);$o=$input['data']??[]; if(empty($o['lines']))error('Commande vide');$o['id']=$o['id']??('CMD-WEB-'.time().rand(100,999));$o['status']=$o['status']??'nouvelle';$o['date']=$o['date']??date('c');array_unshift($orders,$o);set_sync($db,'wwe_orders1',$orders);ok(['order_id'=>$o['id']]);}
if($action==='update_order_status'){$id=$input['order_id']??'';$status=$input['status']??'';$orders=get_sync($db,'wwe_orders1',[]);foreach($orders as &$o){if(($o['id']??'')===$id){$o['status']=$status;$o['updated_at']=date('c');}}set_sync($db,'wwe_orders1',$orders);ok(null,'Statut mis à jour');}
if($action==='add_notif'){$n=get_sync($db,'wwe_n5',[]);$id=time()*1000+rand(0,999);array_unshift($n,['id'=>$id,'msg'=>$input['msg']??'','doc_id'=>$input['doc_id']??null,'type'=>$input['type']??'info','date'=>date('c'),'read'=>false]);set_sync($db,'wwe_n5',$n);ok(['id'=>$id]);}
if($action==='stats'){ok(['sync_keys'=>(int)$db->query('SELECT COUNT(*) FROM smardis_sync_store')->fetchColumn(),'users'=>count(get_sync($db,'wwe_u5',[])),'products'=>count(get_sync($db,'wwe_p5',[])),'orders'=>count(get_sync($db,'wwe_orders1',[]))]);}
error('Action inconnue: '.$action,404);
?>
