# 🚀 SMARDIS — Guide d'installation complet
## Hébergement web (cPanel) + Base de données MySQL

---

## 📁 Fichiers à uploader sur votre hosting

```
votre-domaine.com/
├── index.html          ← ERP SMARDIS
├── boutique.html       ← Boutique en ligne
├── api.php             ← Backend PHP (NE PAS MODIFIER)
├── config.php          ← ⚙️ À CONFIGURER (étape 2)
├── smardis-api.js      ← Couche sécurité (NE PAS MODIFIER)
├── shared.js           ← Fonctions partagées
├── shared.css          ← Styles partagés
└── .htaccess           ← Sécurité Apache
```

---

## 📋 ÉTAPES D'INSTALLATION

### ✅ Étape 1 — Créer la base de données MySQL

1. Connectez-vous à **cPanel** de votre hébergeur
2. Allez dans **MySQL Databases** (ou Bases de données MySQL)
3. Créez une nouvelle base : `smardis_db`
4. Créez un utilisateur MySQL (ex: `smardis_user`)
5. Définissez un mot de passe fort
6. Donnez **TOUS LES PRIVILEGES** à cet utilisateur sur `smardis_db`
7. **Notez** : hostname, nom BDD, utilisateur, mot de passe

---

### ✅ Étape 2 — Importer la structure de la base

1. Dans cPanel → **phpMyAdmin**
2. Sélectionnez votre base `smardis_db` (colonne gauche)
3. Cliquez sur **Importer** (barre du haut)
4. Sélectionnez le fichier `db.sql`
5. Cliquez **Exécuter**

✅ Résultat: Les tables sont créées avec les comptes de démonstration

---

### ✅ Étape 3 — Configurer config.php

Ouvrez `config.php` et remplissez avec vos informations :

```php
define('DB_HOST', 'localhost');     // Généralement 'localhost'
define('DB_NAME', 'smardis_db');    // Nom de votre base MySQL
define('DB_USER', 'smardis_user');  // Votre utilisateur MySQL
define('DB_PASS', 'VotreMotDePasse123!');  // Votre mot de passe
define('APP_SECRET', 'ChangeZCeSecretUniqueAuHasard2024!');
define('ALLOWED_ORIGIN', 'https://votre-domaine.com');
```

---

### ✅ Étape 4 — Uploader les fichiers

**Via FTP (FileZilla) :**
1. Connectez-vous à votre FTP
2. Allez dans `public_html/` (ou votre dossier web)
3. Créez un dossier `smardis/` (optionnel)
4. Uploadez TOUS les fichiers

**Via cPanel File Manager :**
1. cPanel → File Manager
2. Ouvrez `public_html/`
3. Cliquez **Upload** et uploader tous les fichiers

---

### ✅ Étape 5 — Tester l'API

Ouvrez dans votre navigateur :
```
https://votre-domaine.com/api.php?action=ping
```

Réponse attendue :
```json
{"success":true,"mysql":true,"sync_store_keys":0}
```

---

### ✅ Étape 6 — Accéder à l'application

| Application | URL |
|-------------|-----|
| **ERP SMARDIS** | `https://votre-domaine.com/index.html` |
| **Boutique** | `https://votre-domaine.com/boutique.html` |

---

## 🔐 Comptes par défaut

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| **Admin** | admin@smardis.ma | admin123 |
| **Vendeur Terrain** | vendeur@smardis.ma | vendeur123 |
| **Magasinier** | stock@smardis.ma | stock123 |
| **Caissier POS** | caissier@smardis.ma | caissier123 |

> ⚠️ **IMPORTANT** : Changez ces mots de passe dès la première connexion via l'ERP !

---

## 🔒 SÉCURITÉ — Ce qui est implémenté

### 1. Session par navigateur/appareil
- Chaque navigateur doit se connecter indépendamment
- Ouvrir l'ERP sur un autre appareil → affiche la page de **login** obligatoire
- Les sessions **ne sont pas partagées** entre les appareils

### 2. Expiration automatique (10 minutes)
- Après **10 minutes d'inactivité** → déconnexion automatique
- Avertissement **1 minute avant** avec bouton "Rester connecté"
- Le timer se remet à zéro à chaque clic/mouvement

### 3. Tokens serveur
- Chaque connexion génère un **token unique** stocké dans MySQL
- Le token expire après **8 heures** même si actif
- Stocké localement dans `localStorage('smardis_srv_token')`

### 4. Données en MySQL
- Toutes les données sont sauvegardées en MySQL (table `smardis_sync_store`)
- Synchronisation automatique toutes les 5 secondes
- La session (`wwe_s5`) n'est JAMAIS stockée dans MySQL

---

## 🔧 Dépannage

| Problème | Solution |
|----------|---------|
| Page blanche | Vérifiez PHP 7.4+ dans cPanel |
| Erreur DB | Vérifiez config.php (host, db, user, password) |
| Login échoue | Testez `api.php?action=ping` → vérifiez MySQL |
| Session partagée | Videz le cache + vider `smardis_sync_store` de la clé `wwe_s5` |
| Données perdues | Vérifiez que `smardis_sync_store` est bien créée |

### Réinitialiser une session bloquée (Console F12)
```javascript
localStorage.removeItem('smardis_srv_token');
localStorage.removeItem('wwe_s5');
location.reload();
```

### Tester la base de données (Console F12)
```javascript
smardisDBTest().then(r => console.log(r));
```

### Forcer la synchronisation (Console F12)
```javascript
smardisForceSync().then(() => console.log('Sync OK'));
```

---

## 📞 Informations techniques

| Élément | Détail |
|---------|--------|
| **PHP requis** | 7.4 ou supérieur |
| **MySQL requis** | 5.7+ ou MariaDB 10.3+ |
| **Extension PHP** | PDO + pdo_mysql |
| **Navigateurs** | Chrome, Firefox, Safari, Edge |

---

*SMARDIS GROUPE — Système de Gestion Intégré*
