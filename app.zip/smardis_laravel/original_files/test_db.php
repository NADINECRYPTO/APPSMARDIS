<?php
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');
try {
  $db = getDB();
  $tables = [];
  foreach ($db->query("SHOW TABLES") as $row) { $tables[] = array_values($row)[0]; }
  echo json_encode(['success'=>true,'message'=>'Connexion MySQL OK','database'=>DB_NAME,'user'=>DB_USER,'tables'=>$tables], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['success'=>false,'error'=>$e->getMessage(),'fix'=>'Vérifiez DB_HOST, DB_NAME, DB_USER, DB_PASS et les privilèges MySQL.'], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
}
