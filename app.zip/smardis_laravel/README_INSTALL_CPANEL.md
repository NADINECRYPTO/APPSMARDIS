# SMARDIS Laravel — Installation cPanel

## 1) Upload
- Envoyez tout ce dossier ZIP sur cPanel et décompressez-le dans un dossier non public, par exemple: `/home/USER/smardis_laravel`.
- Le domaine ou sous-domaine doit pointer vers: `/home/USER/smardis_laravel/public`.

## 2) Base MySQL
- Créez une base MySQL + utilisateur dans cPanel.
- Donnez tous les privilèges à l'utilisateur.

## 3) Fichier .env
Copiez `.env.example` vers `.env` et modifiez:

```env
APP_URL=https://votre-domaine.com
DB_DATABASE=nom_base
DB_USERNAME=nom_user
DB_PASSWORD=mot_de_passe
APP_DEBUG=false
```

## 4) Commandes SSH cPanel
```bash
cd /home/USER/smardis_laravel
composer install --no-dev --optimize-autoloader
cp .env.example .env
php artisan key:generate
php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## 5) Liens
- ERP/POS: `https://votre-domaine.com/`
- Boutique: `https://votre-domaine.com/boutique`
- Diagnostic: `https://votre-domaine.com/diagnostic`
- API test: `https://votre-domaine.com/api/smardis?action=ping`

## Comptes par défaut
- Admin: `admin@smardis.ma` / `admin123`
- Stock: `stock@smardis.ma` / `stock123`
- POS: `caissier@smardis.ma` / `caissier123`

## Important
Le concept original est conservé: ERP/POS + boutique + synchronisation MySQL avec les clés `wwe_*`. La session `wwe_s5` reste locale pour éviter que plusieurs appareils partagent la même session.
